var e=`src`,t=`playlist`,n=`playlist-open`,r=`preload-metadata`,i=`prefer-media-metadata`,a=`midi-oscillator`,o=`track-index`,s=`title`,c=`artist`,l=`type`,u=`https://w.soundcloud.com/player/api.js`,d=globalThis.HTMLElement??class{},f=null,p=e=>typeof e==`object`&&!!e,m=e=>{if(e===null)return;let t=e.trim().toLowerCase();if(t===``||t===`true`)return!0;if(t===`false`)return!1},h=e=>{if(e.type)return e.type;let t=e.src.toLowerCase();return t.includes(`soundcloud.com`)?`soundcloud`:/\.(?:mid|midi)(?:[?#].*)?$/.test(t)?`midi`:`audio`},g=e=>({...e,tracks:[...e.tracks],type:e.track?h(e.track):void 0}),_=e=>{if(typeof e==`string`){let t=e.trim();return t?{src:t}:null}if(!p(e)||typeof e.src!=`string`)return null;let t=e.src.trim();if(!t)return null;let n=e.type===`audio`||e.type===`soundcloud`||e.type===`midi`?e.type:void 0,r={src:t};if(typeof e.artist==`string`&&(r.artist=e.artist),typeof e.preferMediaMetadata==`boolean`)r.preferMediaMetadata=e.preferMediaMetadata;else if(typeof e.preferMediaMetadata==`string`){let t=m(e.preferMediaMetadata);t!==void 0&&(r.preferMediaMetadata=t)}return typeof e.title==`string`&&(r.title=e.title),n&&(r.type=n),r},v=e=>{if(!e)return[];try{let t=JSON.parse(e);return(Array.isArray(t)?t:[t]).map(e=>_(e)).filter(e=>e!==null)}catch{return e.split(`
`).map(e=>_(e)).filter(e=>e!==null)}},y=async()=>{let e=globalThis.SC;if(e?.Widget)return e;if(f)return f;if(typeof document>`u`)throw Error(`SoundCloud playback requires a browser document.`);return f=new Promise((e,t)=>{let n=document.querySelector(`script[src="${u}"]`),r=n??document.createElement(`script`),i=()=>{let t=globalThis.SC;t?.Widget&&e(t)};r.addEventListener(`load`,i,{once:!0}),r.addEventListener(`error`,()=>t(Error(`Unable to load SoundCloud Widget API.`)),{once:!0}),n||(r.async=!0,r.src=u,document.head.append(r)),i()}),f},b=t=>t.localName===`jukette-track`?_({artist:t.getAttribute(c)??void 0,preferMediaMetadata:t.getAttribute(i)??void 0,src:t.getAttribute(e)??``,title:t.getAttribute(s)??void 0,type:t.getAttribute(l)??void 0}):null,x=class{iframe;callbacks;currentIsStale=()=>!1;eventsBound=!1;loadId=0;loadedDuration=0;loadedSrc=``;resolvePlay=null;silentPause=!1;widget=null;constructor(e,t){this.iframe=e,this.callbacks=t}get hasWidget(){return this.widget!==null}getPlayerUrl(e){let t=new URL(`https://w.soundcloud.com/player/`);return t.searchParams.set(`url`,e),t.searchParams.set(`auto_play`,`false`),t.searchParams.set(`visual`,`false`),t.toString()}prepare(e){!this.widget&&!this.iframe.src&&(this.iframe.src=this.getPlayerUrl(e))}async load(e,t){this.currentIsStale=t;let n=await this.getWidget(t);if(!n||t())return!1;if(this.loadedSrc===e)return this.emitDuration(n,t),!0;let r=this.loadId+=1;return this.loadedDuration=0,!await new Promise(t=>{let r=!1,i=window.setTimeout(()=>a(!1),1e4),a=e=>{r||(r=!0,window.clearTimeout(i),t(e))};n.load(e,{auto_play:!1,callback:()=>a(!0)})})||t()||r!==this.loadId?!1:(this.loadedSrc=e,this.emitDuration(n,t),!0)}pause(e={}){e.silent&&(this.silentPause=!0),this.resolvePlay?.(!1),this.resolvePlay=null,this.widget?.pause()}async play(e){return this.currentIsStale=e,!this.widget||e()?!1:(this.silentPause=!1,new Promise(e=>{let t=!1,n=window.setTimeout(()=>r(!1),5e3),r=r=>{t||(t=!0,window.clearTimeout(n),this.resolvePlay=null,e(r))};this.resolvePlay=r,this.widget?.play()}))}requestPosition(e){this.currentIsStale=e,this.widget?.getPosition(t=>{e()||this.callbacks.onProgress(t/1e3),this.callbacks.onPositionRequestComplete()})}seek(e){this.widget?.seekTo(Math.max(0,e)*1e3)}setVolume(e){this.widget?.setVolume(Math.max(0,Math.min(100,e*100)))}async getWidget(e){if(this.widget)return this.widget;let t=await y();if(e())return null;let n=t.Widget(this.iframe);return this.widget=n,this.bindEvents(t,n),n.bind(t.Widget.Events.READY,()=>{this.isStale()||n!==this.widget||(n.getDuration(e=>{this.isStale()||n!==this.widget||(this.loadedDuration=e/1e3,this.callbacks.onDuration(this.loadedDuration))}),this.requestPosition(this.currentIsStale))}),n}bindEvents(e,t){this.eventsBound||(this.eventsBound=!0,t.bind(e.Widget.Events.PLAY,()=>{this.isStale()||t!==this.widget||(this.silentPause=!1,this.resolvePlay?.(!0),this.callbacks.onPlay())}),t.bind(e.Widget.Events.PLAY_PROGRESS,e=>{this.isStale()||t!==this.widget||e&&typeof e==`object`&&(`currentPosition`in e&&typeof e.currentPosition==`number`&&this.callbacks.onProgress(e.currentPosition/1e3),`relativePosition`in e&&typeof e.relativePosition==`number`&&this.callbacks.onRelativeProgress(e.relativePosition))}),t.bind(e.Widget.Events.PAUSE,()=>{if(!(this.isStale()||t!==this.widget)){if(this.silentPause){this.silentPause=!1;return}this.callbacks.onPause()}}),t.bind(e.Widget.Events.FINISH,()=>{this.isStale()||t!==this.widget||this.callbacks.onFinish()}))}isStale(){return this.currentIsStale()}emitDuration(e,t){this.loadedDuration>0&&this.callbacks.onDuration(this.loadedDuration),e.getDuration(e=>{t()||(this.loadedDuration=e/1e3,this.callbacks.onDuration(this.loadedDuration))})}},S=class extends d{static observedAttributes=[e,t,n,r,i,a,o];audio;iframe;playButton;previousButton;nextButton;volumeInput;seekInput;playlistButton;playlistElement;titleElement;metaElement;statusElement;elapsedTimeElement;remainingTimeElement;totalTimeElement;tracks=[];trackDurations=new Map;trackMetadata=new Map;index=0;desiredPlaying=!1;playing=!1;trackLoadId=0;duration=0;midiTimer=0;midiStartedAt=0;midiPausedAt=0;midiAudio=null;midiGain=null;midiSequence=null;midiSources=[];soundCloudAdapter=null;soundCloudPosition=0;soundCloudPositionRequested=!1;restartOnNextPlay=!1;progressFrame=0;metadataPreloadId=0;trackObserver=null;playlistOverride=null;loadedTrackKey=``;constructor(){super(),typeof MutationObserver<`u`&&(this.trackObserver=new MutationObserver(()=>this.syncChildTracks()));let e=this.attachShadow({mode:`open`});e.innerHTML=`
			<style>
				:host {
					--jukette-control-size: 2em;
					display: block;
					font: inherit;
					color: inherit;
				}

				* {
					box-sizing: border-box;
				}

				.player {
					border: 1px solid currentColor;
					display: grid;
					gap: 0.5lh;
					padding: 0.5rlh 1em;
				}

				.track {
					display: grid;
					min-inline-size: 0;
				}

				.progress {
					display: grid;
					gap: 0;
				}

				.title,
				.meta {
					overflow: hidden;
					text-overflow: ellipsis;
					white-space: nowrap;
				}

				.title {
					font-weight: 700;
				}

				.meta,
				.status,
				.time {
					opacity: 0.75;
				}

				.status {
					min-block-size: 1lh;
					overflow: hidden;
					text-overflow: ellipsis;
					white-space: nowrap;
				}

				.controls {
					align-items: center;
					display: grid;
					gap: 0.5lh 0.5em;
					grid-template-areas: "previous play next volume playlist";
					grid-template-columns: repeat(3, var(--jukette-control-size)) minmax(7rem, 1fr) var(--jukette-control-size);
				}

				.previous {
					grid-area: previous;
				}

				.play {
					grid-area: play;
				}

				.next {
					grid-area: next;
				}

				.volume {
					grid-area: volume;
				}

				.playlist-toggle {
					grid-area: playlist;
				}

				button {
					align-items: center;
					appearance: none;
					background: transparent;
					border: 1px solid currentColor;
					block-size: var(--jukette-control-size);
					color: inherit;
					cursor: pointer;
					display: inline-grid;
					font: inherit;
					inline-size: var(--jukette-control-size);
					justify-content: center;
					padding: 0;
				}

				button:focus-visible {
					outline: 2px solid currentColor;
					outline-offset: 0;
					outline-radius: 0;
				}

				button:active {
					background: rgb(from currentColor calc(255 - r) calc(255 - g) calc(255 - b));
					color: rgb(from currentColor calc(255 - r) calc(255 - g) calc(255 - b));
				}

				button[aria-pressed="true"] {
					background: rgb(from currentColor calc(255 - r) calc(255 - g) calc(255 - b));
					color: rgb(from currentColor calc(255 - r) calc(255 - g) calc(255 - b));
				}

				button:disabled {
					cursor: default;
					opacity: 0.45;
				}

				input[type="range"] {
					accent-color: currentColor;
				}

				.seek {
					display: grid;
				}

				.time {
					display: grid;
					gap: 0.5em;
					grid-template-columns: repeat(3, 1fr);
					font-variant-numeric: tabular-nums;
				}

				.time span:nth-child(2) {
					text-align: center;
				}

				.time span:nth-child(3) {
					text-align: end;
				}

				.playlist {
					border-block-start: 1px solid currentColor;
					counter-reset: jukette-playlist;
					display: none;
					gap: 0.5lh 0;
					list-style: none;
					margin: 0;
					padding: 1lh 0 0.5lh;
				}

				:host([playlist-open]) .playlist {
					display: grid;
				}

				.playlist li {
					align-items: start;
					counter-increment: jukette-playlist;
					display: grid;
				}

				.playlist li button {
					padding-inline: 0.5em;
				}

				.playlist li button::before {
					content: counter(jukette-playlist) ".";
					grid-column: 1;
					grid-row: 1 / span 2;
					font-variant-numeric: tabular-nums;
					text-align: end;
				}

				.playlist li button[aria-current="true"] {
					background: rgb(from currentColor calc(255 - r) calc(255 - g) calc(255 - b));
					color: rgb(from currentColor calc(255 - r) calc(255 - g) calc(255 - b));
				}

				.playlist button {
					align-items: start;
					block-size: auto;
					border: 0;
					display: grid;
					gap: 0 0.5em;
					grid-template-columns: 2ch minmax(0, 1fr) auto;
					inline-size: 100%;
					text-align: start;
				}

				.playlist-title,
				.playlist-artist {
					overflow: hidden;
					text-overflow: ellipsis;
					white-space: nowrap;
				}

				.playlist-title {
					font-weight: 700;
					grid-column: 2;
				}

				.playlist-artist,
				.playlist-duration {
					opacity: 0.75;
				}

				.playlist-duration {
					align-self: center;
					font-variant-numeric: tabular-nums;
					grid-column: 3;
					grid-row: 1 / span 2;
					white-space: nowrap;
				}

				.playlist-artist {
					grid-column: 2;
				}

				.soundcloud {
					border: 0;
					block-size: 166px;
					display: none;
					inline-size: 100%;
				}

				audio {
					display: none;
				}

				@media (max-width: 34em) {
					.controls {
						grid-template-areas:
							"volume volume volume volume volume"
							"previous play next . playlist";
						grid-template-columns: repeat(3, var(--jukette-control-size)) minmax(0, 1fr) var(--jukette-control-size);
						justify-content: start;
					}
				}
			</style>

			<div class="player">
				<div class="track" aria-live="polite">
					<div class="title"></div>
					<div class="meta"></div>
				</div>
				<div class="progress">
					<div class="status" role="status" aria-live="polite"></div>
					<div class="seek">
						<input class="seek-input" type="range" min="0" max="1000" value="0" aria-label="Seek" />
						<div class="time" aria-live="off">
							<span class="elapsed">0:00</span>
							<span class="remaining">-0:00</span>
							<span class="total">0:00</span>
						</div>
					</div>
				</div>
				<div class="controls">
					<button class="previous" type="button" aria-label="Previous or restart track">&#x23ee;&#xfe0e;</button>
					<button class="play" type="button" aria-label="Play">▶</button>
					<button class="next" type="button" aria-label="Next track">&#x23ed;&#xfe0e;</button>
					<input class="volume" type="range" min="0" max="1" step="0.01" value="1" aria-label="Volume" />
					<button class="playlist-toggle" type="button" aria-label="Toggle playlist" aria-pressed="false">☰</button>
				</div>
				<iframe class="soundcloud" title="SoundCloud player" allow="autoplay"></iframe>
				<audio preload="metadata"></audio>
				<ol class="playlist"></ol>
			</div>
		`,this.audio=this.query(e,`audio`),this.iframe=this.query(e,`.soundcloud`),this.playButton=this.query(e,`.play`),this.previousButton=this.query(e,`.previous`),this.nextButton=this.query(e,`.next`),this.volumeInput=this.query(e,`.volume`),this.seekInput=this.query(e,`.seek-input`),this.playlistButton=this.query(e,`.playlist-toggle`),this.playlistElement=this.query(e,`.playlist`),this.titleElement=this.query(e,`.title`),this.metaElement=this.query(e,`.meta`),this.statusElement=this.query(e,`.status`),this.elapsedTimeElement=this.query(e,`.elapsed`),this.remainingTimeElement=this.query(e,`.remaining`),this.totalTimeElement=this.query(e,`.total`),this.soundCloudAdapter=new x(this.iframe,{onDuration:e=>{this.duration=e,this.setTrackDuration(this.currentTrack,e),this.syncProgress(this.soundCloudPosition,this.duration)},onFinish:()=>this.finishTrack(),onPause:()=>{let e=this.playing||this.desiredPlaying;this.desiredPlaying=!1,this.playing=!1,this.syncPlayingState(),e&&this.emitJuketteEvent(`jukette:pause`)},onPlay:()=>{this.desiredPlaying=!0,this.playing=!0,this.syncPlayingState(),this.emitJuketteEvent(`jukette:play`)},onPositionRequestComplete:()=>{this.soundCloudPositionRequested=!1},onProgress:e=>{this.soundCloudPosition=e,this.soundCloudPositionRequested=!1,this.syncProgress(this.soundCloudPosition,this.duration)},onRelativeProgress:e=>{this.duration<=0||(this.soundCloudPosition=e*this.duration,this.syncProgress(this.soundCloudPosition,this.duration))}}),this.playButton.addEventListener(`click`,()=>this.toggle()),this.previousButton.addEventListener(`click`,()=>this.previous()),this.nextButton.addEventListener(`click`,()=>this.next()),this.playlistButton.addEventListener(`click`,()=>this.togglePlaylist()),this.volumeInput.addEventListener(`input`,()=>this.syncVolume()),this.seekInput.addEventListener(`input`,()=>this.seekFromInput()),this.audio.addEventListener(`loadedmetadata`,()=>this.syncFromMedia()),this.audio.addEventListener(`timeupdate`,()=>this.syncFromMedia()),this.audio.addEventListener(`ended`,()=>this.finishTrack())}connectedCallback(){this.trackObserver?.observe(this,{attributeFilter:[c,i,e,s,l],attributes:!0,childList:!0,subtree:!0}),this.syncTracks(),this.syncPlaylistButton(),this.loadTrack()}disconnectedCallback(){this.trackObserver?.disconnect(),this.stopProgressLoop(),this.stopMidi()}attributeChangedCallback(e,t,a){if(t!==a){if(e===r||e===i){this.renderCurrentTrack(),this.renderPlaylist(),this.preloadPlaylistMetadata();return}if(e===n){let e=a!==null;this.syncPlaylistButton(),this.emitJuketteEvent(`jukette:playlisttoggle`,{open:e});return}this.syncTracks(),this.loadTrack()}}get currentTrack(){return this.tracks[this.index]??null}get currentTrackIndex(){return this.index}get currentTime(){return this.getCurrentTime()}set currentTime(e){this.seek(e)}get playlist(){return[...this.tracks]}get playlistOpen(){return this.hasAttribute(n)}set playlistOpen(e){this.toggleAttribute(n,e)}get totalTracks(){return this.tracks.length}get preloadMetadata(){return this.hasAttribute(r)}set preloadMetadata(e){this.toggleAttribute(r,e)}get preferMediaMetadata(){return this.hasAttribute(i)}set preferMediaMetadata(e){this.toggleAttribute(i,e)}get midiOscillator(){return I(this.getAttribute(a))}set midiOscillator(e){this.setAttribute(a,e)}set playlist(e){this.playlistOverride=e.map(e=>_(e)).filter(e=>e!==null),this.tracks=[...this.playlistOverride],this.index=0,this.renderPlaylist(),this.preloadPlaylistMetadata(),this.loadTrack()}async play(){let e=this.currentTrack;if(!e)return;this.desiredPlaying=!0;let t=this.trackLoadId,n=h(e);if(n===`audio`){if(this.setStatus(`Starting audio`),await this.audio.play(),t!==this.trackLoadId)return;this.playing=!0}else n===`midi`?await this.playMidi(t):n===`soundcloud`?await this.playSoundCloud(t):this.playing=!0;this.syncPlayingState(),n!==`soundcloud`&&this.emitJuketteEvent(`jukette:play`)}pause(){let e=this.playing||this.desiredPlaying;this.setStatus(),this.desiredPlaying=!1,h(this.currentTrack??{src:``})===`audio`?this.audio.pause():h(this.currentTrack??{src:``})===`midi`?this.pauseMidi():h(this.currentTrack??{src:``})===`soundcloud`&&this.soundCloudAdapter?.pause(),this.playing=!1,this.syncPlayingState(),e&&this.emitJuketteEvent(`jukette:pause`)}toggle(){if(this.playing){this.pause();return}this.play()}next(){if(this.tracks.length===0)return;let e=this.index,t=this.desiredPlaying||this.playing;this.index=(this.index+1)%this.tracks.length,this.restartOnNextPlay=!0,this.loadTrack(),this.emitJuketteEvent(`jukette:next`,{direction:`next`,fromIndex:e,toIndex:this.index}),t&&this.play()}previous(){if(this.tracks.length===0)return;if(this.getCurrentTime()>3){this.restartOnNextPlay=!0,this.seek(0),this.emitJuketteEvent(`jukette:restart`),(this.desiredPlaying||this.playing)&&this.play();return}let e=this.index,t=this.desiredPlaying||this.playing;this.index=(this.index-1+this.tracks.length)%this.tracks.length,this.restartOnNextPlay=!0,this.loadTrack(),this.emitJuketteEvent(`jukette:previous`,{direction:`previous`,fromIndex:e,toIndex:this.index}),t&&this.play()}seek(e){let t=this.currentTrack;t&&(this.setStatus(`Seeking`),h(t)===`audio`?this.audio.currentTime=e:h(t)===`midi`?(this.midiPausedAt=Math.max(0,e),this.playing&&this.playMidi()):h(t)===`soundcloud`&&(this.soundCloudPosition=Math.max(0,e),this.soundCloudAdapter?.seek(e)),this.syncProgress(e,this.duration),this.emitJuketteEvent(`jukette:seek`),window.setTimeout(()=>{(this.playing||!this.desiredPlaying)&&this.setStatus()},500))}getCurrentTime(){let e=this.currentTrack;return e?h(e)===`audio`?this.audio.currentTime:h(e)===`midi`?this.playing?(performance.now()-this.midiStartedAt)/1e3+this.midiPausedAt:this.midiPausedAt:h(e)===`soundcloud`?this.soundCloudPosition:0:0}getJuketteEventDetail(e={}){return g({currentTime:this.getCurrentTime(),duration:this.duration,index:this.index,playing:this.playing,playlistOpen:this.playlistOpen,track:this.currentTrack,tracks:this.tracks,volume:Number(this.volumeInput.value),...e})}emitJuketteEvent(e,t={}){typeof CustomEvent>`u`||this.dispatchEvent(new CustomEvent(e,{bubbles:!0,composed:!0,detail:this.getJuketteEventDetail(t)}))}query(e,t){let n=e.querySelector(t);if(!n)throw Error(`Missing Jukette element: ${t}`);return n}syncTracks(){let n=this.getChildTracks(),r=v(this.getAttribute(t)),i=_(this.getAttribute(e)??void 0);this.tracks=this.playlistOverride??(n.length>0?n:r.length>0?r:i?[i]:[]);let a=Number(this.getAttribute(o));this.index=Math.min(Number.isInteger(a)&&a>=0?a:this.index,Math.max(0,this.tracks.length-1)),this.renderPlaylist(),this.preloadPlaylistMetadata()}syncChildTracks(){if(this.playlistOverride)return;let e=this.currentTrack;if(this.syncTracks(),this.currentTrack?.src===e?.src){this.renderPlaylist();return}this.loadTrack(),this.playing&&this.play()}getChildTracks(){return Array.from(this.children).map(e=>b(e)).filter(e=>e!==null)}loadTrack(){this.trackLoadId+=1;let e=this.loadedTrackKey;this.stopMidi(),this.audio.pause(),this.audio.removeAttribute(`src`),this.soundCloudAdapter?.pause({silent:!0}),this.soundCloudPosition=0,this.soundCloudPositionRequested=!1,this.playing=!1,this.duration=0,this.midiSequence=null,this.midiPausedAt=0,this.syncProgress(0,0);let t=this.currentTrack;if(!t){this.loadedTrackKey=``,this.titleElement.textContent=`No track`,this.metaElement.textContent=``,this.statusElement.textContent=``,this.playButton.disabled=!0,e&&this.emitJuketteEvent(`jukette:trackchange`);return}let n=h(t),r=this.getTrackKey(t);this.loadedTrackKey=r,this.duration=this.getTrackDuration(t)??0,this.dataset.kind=n,this.playButton.disabled=!1,this.renderCurrentTrack(),this.setStatus(),this.syncProgress(0,this.duration),n===`audio`?(this.setStatus(`Loading audio`),this.audio.src=t.src,this.audio.volume=Number(this.volumeInput.value),this.audio.load(),this.audio.currentTime=0,this.preloadAudioFileMetadata(t,this.metadataPreloadId)):n===`soundcloud`?(this.setStatus(`Preparing SoundCloud`),this.loadSoundCloudTrack(t)):(this.setStatus(`Ready`),window.setTimeout(()=>{this.playing||this.setStatus()},700)),this.renderPlaylist(),this.syncPlayingState(),r!==e&&this.emitJuketteEvent(`jukette:trackchange`)}renderPlaylist(){this.playlistElement.replaceChildren(...this.tracks.map((e,t)=>{let n=this.getTrackDisplay(e),r=document.createElement(`li`),i=document.createElement(`button`),a=document.createElement(`span`),o=document.createElement(`span`),s=document.createElement(`span`),c=this.getTrackDuration(e),l=c===void 0?`--:--`:this.formatTime(c);return i.type=`button`,i.setAttribute(`aria-label`,[n.title,n.artist,c===void 0?`unknown duration`:l].filter(Boolean).join(`, `)),a.className=`playlist-title`,a.textContent=n.title,o.className=`playlist-artist`,o.textContent=n.artist,s.className=`playlist-duration`,s.textContent=l,i.append(a,o,s),t===this.index&&i.setAttribute(`aria-current`,`true`),i.addEventListener(`click`,()=>{this.desiredPlaying=!0,this.restartOnNextPlay=!0,this.index=t,this.loadTrack(),this.play()}),r.append(i),r}))}getTrackDuration(e){if(e)return this.trackDurations.get(this.getTrackKey(e))}setTrackDuration(e,t){if(!e||!Number.isFinite(t)||t<=0)return;let n=this.getTrackKey(e),r=this.trackDurations.get(n);r!==void 0&&Math.abs(r-t)<.5||(this.trackDurations.set(n,t),this.renderPlaylist())}getTrackKey(e){return`${h(e)}:${e.src}`}trackPrefersMediaMetadata(e){return e.preferMediaMetadata??this.preferMediaMetadata}getTrackDisplay(e){let t=this.trackPrefersMediaMetadata(e)?this.trackMetadata.get(this.getTrackKey(e)):void 0;return{artist:t?.artist||e.artist||``,title:t?.title||e.title||e.src}}renderCurrentTrack(){let e=this.currentTrack;if(!e)return;let t=this.getTrackDisplay(e);this.titleElement.textContent=t.title,this.metaElement.textContent=t.artist||h(e)}setTrackMetadata(e,t){if(!e)return;let n={artist:t.artist?.trim()||void 0,title:t.title?.trim()||void 0};if(!n.artist&&!n.title)return;let r=this.getTrackKey(e),i=this.trackMetadata.get(r);i!==void 0&&i.artist===n.artist&&i.title===n.title||(this.trackMetadata.set(r,n),this.currentTrack&&this.getTrackKey(this.currentTrack)===r&&this.renderCurrentTrack(),this.renderPlaylist())}preloadPlaylistMetadata(){this.metadataPreloadId+=1;let e=this.tracks.some(e=>this.trackPrefersMediaMetadata(e));if(!this.preloadMetadata&&!e)return;let t=this.metadataPreloadId;for(let e of this.tracks){let n=h(e),r=this.trackPrefersMediaMetadata(e);n===`audio`?(this.preloadMetadata&&this.preloadAudioMetadata(e,t),r&&this.preloadAudioFileMetadata(e,t)):n===`midi`?(this.preloadMetadata||r)&&this.preloadMidiMetadata(e,t):n===`soundcloud`&&r&&this.preloadSoundCloudMetadata(e,t)}}preloadAudioMetadata(e,t){if(this.getTrackDuration(e)!==void 0||typeof Audio>`u`)return;let n=new Audio,r=()=>{n.removeEventListener(`loadedmetadata`,i),n.removeEventListener(`error`,r),n.removeAttribute(`src`),n.load()},i=()=>{t===this.metadataPreloadId&&this.setTrackDuration(e,n.duration),r()};n.preload=`metadata`,n.addEventListener(`loadedmetadata`,i),n.addEventListener(`error`,r,{once:!0}),n.src=e.src,n.load()}async preloadAudioFileMetadata(e,t){if(this.trackPrefersMediaMetadata(e)&&!this.trackMetadata.has(this.getTrackKey(e))&&!(typeof fetch>`u`))try{let n=await fetch(e.src,{headers:{Range:`bytes=0-65535`}});if(!n.ok)return;let r=j(await n.arrayBuffer());t===this.metadataPreloadId&&this.setTrackMetadata(e,r)}catch{}}async preloadMidiMetadata(e,t){try{let n=await B(e.src);t===this.metadataPreloadId&&(this.preloadMetadata&&this.setTrackDuration(e,n.duration),this.trackPrefersMediaMetadata(e)&&this.setMidiTrackMetadata(e,n))}catch{}}async preloadSoundCloudMetadata(e,t){if(this.trackPrefersMediaMetadata(e)&&!this.trackMetadata.has(this.getTrackKey(e))&&!(typeof fetch>`u`))try{let n=new URL(`https://soundcloud.com/oembed`);n.searchParams.set(`format`,`json`),n.searchParams.set(`url`,e.src);let r=await fetch(n);if(!r.ok)return;let i=M(await r.json());t===this.metadataPreloadId&&this.setTrackMetadata(e,i)}catch{}}setMidiTrackMetadata(e,t){t.metadata?.title&&this.setTrackMetadata(e,{title:t.metadata.title})}togglePlaylist(){this.playlistOpen=!this.playlistOpen}syncPlaylistButton(){this.playlistButton.setAttribute(`aria-pressed`,String(this.playlistOpen))}syncVolume(){this.audio.volume=Number(this.volumeInput.value),this.midiGain&&(this.midiGain.gain.value=Number(this.volumeInput.value)),this.soundCloudAdapter?.setVolume(Number(this.volumeInput.value)),this.emitJuketteEvent(`jukette:volumechange`)}seekFromInput(){this.duration&&this.seek(Number(this.seekInput.value)/1e3*this.duration)}syncFromMedia(){this.duration=Number.isFinite(this.audio.duration)?this.audio.duration:0,this.setTrackDuration(this.currentTrack,this.duration),this.syncProgress(this.audio.currentTime,this.duration),this.playing||this.setStatus()}syncProgress(e,t){let n=Number.isFinite(t)?Math.max(0,t):0,r=Number.isFinite(e)?Math.min(Math.max(0,e),n||2**53-1):0,i=n>0?Math.min(1,Math.max(0,r/n)):0;this.seekInput.value=String(Math.round(i*1e3)),this.elapsedTimeElement.textContent=this.formatTime(r),this.remainingTimeElement.textContent=`-${this.formatTime(Math.max(0,n-r))}`,this.totalTimeElement.textContent=this.formatTime(n)}formatTime(e){let t=Math.floor(Number.isFinite(e)?Math.max(0,e):0),n=Math.floor(t/60),r=t%60;return`${n}:${String(r).padStart(2,`0`)}`}syncPlayingState(){this.playButton.textContent=this.playing?`Ⅱ`:`▶`,this.playButton.setAttribute(`aria-label`,this.playing?`Pause`:`Play`),this.playing?(this.setStatus(),this.startProgressLoop()):this.stopProgressLoop()}setStatus(e=``){this.statusElement.textContent=e}finishTrack(){this.emitJuketteEvent(`jukette:ended`),this.next()}async playMidi(e=this.trackLoadId){let t=this.currentTrack;if(!t)return;if(!this.midiSequence){if(this.setStatus(`Loading MIDI`),this.midiSequence=await B(t.src),e!==this.trackLoadId)return;this.duration=this.midiSequence.duration,this.setTrackDuration(t,this.duration),this.trackPrefersMediaMetadata(t)&&this.setMidiTrackMetadata(t,this.midiSequence),this.syncProgress(this.midiPausedAt,this.duration)}if(this.stopMidi(),e!==this.trackLoadId||(this.playing=!0,this.midiStartedAt=performance.now(),this.ensureMidiAudio(),!this.midiAudio||!this.midiGain||!this.midiSequence))return;this.midiAudio.state===`suspended`&&await this.midiAudio.resume();let n=this.midiPausedAt,r=this.midiAudio.currentTime+.03,i=R(this.midiOscillator,this.midiSequence.metadata?.program);this.midiSources=this.midiSequence.notes.filter(e=>e.start+e.duration>n).map(e=>{let t=this.midiAudio.createOscillator(),a=this.midiAudio.createGain(),o=Math.max(0,e.start-n),s=Math.max(0,n-e.start),c=Math.max(.03,e.duration-s),l=r+o,u=l+c;return t.type=i,t.frequency.value=e.frequency,a.gain.setValueAtTime(0,l),a.gain.linearRampToValueAtTime(e.velocity*.18,l+.01),a.gain.setValueAtTime(e.velocity*.16,Math.max(l+.02,u-.04)),a.gain.linearRampToValueAtTime(0,u),t.connect(a),a.connect(this.midiGain),t.start(l),t.stop(u+.02),t}),this.midiTimer=window.setTimeout(()=>this.finishTrack(),Math.max(0,this.duration-n)*1e3)}async playSoundCloud(e=this.trackLoadId){let t=this.currentTrack;if(!t)return;this.playButton.disabled=!0,this.setStatus(`Loading SoundCloud`);let n=()=>e!==this.trackLoadId,r;try{r=await this.soundCloudAdapter?.load(t.src,n)??!1}catch{r=!1}if(n())return;if(!r){this.playButton.disabled=!1,this.setStatus(`SoundCloud unavailable`);return}this.soundCloudAdapter?.setVolume(Number(this.volumeInput.value)),this.restartOnNextPlay&&(this.soundCloudAdapter?.seek(0),this.soundCloudPosition=0,this.syncProgress(0,this.duration)),this.restartOnNextPlay=!1,this.setStatus(`Starting SoundCloud`);let i=await this.soundCloudAdapter?.play(n);if(!n()){if(!i){this.playButton.disabled=!1,this.setStatus(`SoundCloud did not start`);return}this.playButton.disabled=!1}}loadSoundCloudTrack(e){this.soundCloudPosition=0,this.syncProgress(0,this.getTrackDuration(e)??0),this.soundCloudAdapter?.prepare(e.src)}startProgressLoop(){if(this.progressFrame||typeof requestAnimationFrame>`u`)return;let e=()=>{if(!this.playing){this.progressFrame=0;return}h(this.currentTrack??{src:``})===`soundcloud`&&this.requestSoundCloudPosition(),this.syncProgress(this.getCurrentTime(),this.duration),this.progressFrame=requestAnimationFrame(e)};this.progressFrame=requestAnimationFrame(e)}stopProgressLoop(){if(!this.progressFrame||typeof cancelAnimationFrame>`u`){this.progressFrame=0;return}cancelAnimationFrame(this.progressFrame),this.progressFrame=0,this.syncProgress(this.getCurrentTime(),this.duration)}requestSoundCloudPosition(){if(!this.soundCloudAdapter||this.soundCloudPositionRequested)return;this.soundCloudPositionRequested=!0;let e=this.trackLoadId;window.setTimeout(()=>{e===this.trackLoadId&&(this.soundCloudPositionRequested=!1)},500),this.soundCloudAdapter.requestPosition(()=>e!==this.trackLoadId)}pauseMidi(){this.midiPausedAt=this.getCurrentTime(),this.stopMidi()}stopMidi(){this.midiTimer&&=(window.clearTimeout(this.midiTimer),0);for(let e of this.midiSources)try{e.stop()}catch{}this.midiSources=[]}ensureMidiAudio(){if(this.midiAudio&&this.midiGain)return;let e=globalThis.AudioContext??globalThis.webkitAudioContext;if(!e){this.setStatus(`MIDI playback needs Web Audio`);return}this.midiAudio=new e,this.midiGain=this.midiAudio.createGain(),this.midiGain.gain.value=Number(this.volumeInput.value),this.midiGain.connect(this.midiAudio.destination)}},C=e=>String.fromCharCode(...e),w=e=>String.fromCharCode(...e),T=e=>{let t=[];for(let n=0;n+1<e.length;n+=2)t.push(e[n]<<8|e[n+1]);return String.fromCharCode(...t)},E=(e,t)=>{try{return new TextDecoder(t).decode(e)}catch{return t===`iso-8859-1`?w(e):C(e)}},D=e=>{let t=e.indexOf(`\0`);return(t>=0?e.slice(0,t):e.trimEnd()).trim()},O=(e,t,n=4)=>{let r=0;for(let i=0;i<n;i++)r=r<<7|e[t+i]&127;return r},k=(e,t)=>(e[t]<<24|e[t+1]<<16|e[t+2]<<8|e[t+3])>>>0,A=e=>{if(e.length<2)return``;let t=e[0],n=e.slice(1);return D(t===0?w(n):t===3?E(n,`utf-8`):t===2?T(n):E(n,`utf-16`))},j=e=>{let t=new Uint8Array(e);if(t.length<10||C(t.slice(0,3))!==`ID3`)return{};let n=t[3],r=t[5],i=Math.min(t.length,10+O(t,6)),a=10;if(r&64&&a+4<=i){let e=n===4?O(t,a):k(t,a)+4;a+=e}let o={};for(;a+10<=i;){let e=C(t.slice(a,a+4));if(!/^[A-Z0-9]{4}$/.test(e))break;let r=n===4?O(t,a+4):k(t,a+4),s=a+10,c=s+r;if(r<=0||c>i)break;let l=t.slice(s,c);e===`TIT2`&&(o.title=A(l)),e===`TPE1`&&(o.artist=A(l)),a=c}return o},M=e=>{if(!p(e)||typeof e.title!=`string`)return{};let t=e.title.trim();if(!t)return{};let n=/^(?<title>.+?) by (?<artist>.+)$/.exec(t);return n?.groups?{artist:n.groups.artist.trim()||void 0,title:n.groups.title.trim()||t}:{title:t}},N=class{data;offset=0;constructor(e){this.data=e}get done(){return this.offset>=this.data.length}read(e){let t=this.data.slice(this.offset,this.offset+e);return this.offset+=e,t}unread(e=1){this.offset=Math.max(0,this.offset-e)}readText(e){return String.fromCharCode(...this.read(e))}readU8(){return this.data[this.offset++]??0}readU16(){return this.readU8()<<8|this.readU8()}readU32(){return this.readU8()<<24|this.readU8()<<16|this.readU8()<<8|this.readU8()}readVar(){let e=0,t;do t=this.readU8(),e=e<<7|t&127;while(t&128);return e}},P=e=>440*2**((e-69)/12),F=e=>D(E(e,`utf-8`)),I=e=>e===`sine`||e===`square`||e===`sawtooth`||e===`triangle`?e:`auto`,L=e=>e===void 0?`triangle`:e>=16&&e<=23?`sine`:e>=32&&e<=39||e>=80&&e<=87?`square`:e>=56&&e<=87?`sawtooth`:`triangle`,R=(e,t)=>e===`auto`?L(t):e,z=e=>{let t=new N(new Uint8Array(e));if(t.readText(4)!==`MThd`)throw Error(`Invalid MIDI header.`);let n=t.readU32();t.readU16();let r=t.readU16(),i=t.readU16();if(n>6&&t.read(n-6),i&32768)throw Error(`SMPTE MIDI timing is not supported.`);let a=i,o=[],s={},c,l=5e5,u=0;for(let e=0;e<r&&!t.done&&t.readText(4)===`MTrk`;e++){let e=new N(t.read(t.readU32())),n=new Map,r=0,i=0;for(;!e.done;){let t=e.readVar();i+=t*l/a/1e6;let d=e.readU8();if(d<128?(e.unread(),d=r):r=d,d===255){let t=e.readU8(),n=e.readVar();if(t===81&&n===3){let t=e.read(3);l=t[0]<<16|t[1]<<8|t[2]}else if(t===3){let t=F(e.read(n));!s.title&&t&&(s.title=t)}else e.read(n);continue}if(d===240||d===247){e.read(e.readVar());continue}let f=d&240;if(f===192){let t=e.readU8();c===void 0&&(c=t);continue}if(f===208){e.readU8();continue}let p=e.readU8(),m=e.readU8();if(f===144&&m>0)n.set(p,{start:i,velocity:m/127});else if(f===128||f===144){let e=n.get(p);e&&(o.push({duration:Math.max(.03,i-e.start),frequency:P(p),start:e.start,velocity:e.velocity}),n.delete(p))}u=Math.max(u,i)}}let d={};return s.title&&(d.title=s.title),c!==void 0&&(d.program=c),{duration:Math.max(u,1),metadata:d.title||d.program!==void 0?d:void 0,notes:o}},B=async e=>{let t=await fetch(e);if(!t.ok)throw Error(`Unable to load MIDI file: ${e}`);return z(await t.arrayBuffer())},V=()=>{typeof customElements>`u`||(customElements.get(`jukette-track`)||customElements.define(`jukette-track`,H),customElements.get(`jukette-player`)||customElements.define(`jukette-player`,S))},H=class extends d{};V();var U=(e,t)=>Array.from(e.children).some(e=>e instanceof HTMLButtonElement&&e.classList.contains(t));(({root:e=document,blockSelector:t=`.code-block`,codeSelector:n=`code`,buttonClassName:r=`copy`,label:i=`Copy`,copiedLabel:a=`Copied!`,errorLabel:o=`Unable to copy`,resetDelay:s=1e3}={})=>{let c=[];return e.querySelectorAll(t).forEach(e=>{let t=e.querySelector(n);if(!t||U(e,r))return;let l=document.createElement(`button`);l.classList.add(r),l.type=`button`,l.textContent=i,l.addEventListener(`click`,async()=>{try{await navigator.clipboard.writeText(t.textContent??``),l.setAttribute(`aria-live`,`assertive`),l.textContent=a}catch{l.textContent=o}setTimeout(()=>{l.textContent=i,l.removeAttribute(`aria-live`)},s)}),e.appendChild(l),c.push(l)}),c})({blockSelector:`main .code-block`,copiedLabel:`Copied`});